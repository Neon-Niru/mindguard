# AI check-in configuration

The interview backend uses an OpenAI-compatible chat-completions API. The model only proposes a conversational reply and candidate facts; the server accepts a fact only when its category/field exists in `engine/schema.py`, its type/range is valid, and its evidence is an exact substring of the user's latest message. The burnout engine remains the only scoring component.

## Groq setup

Set these variables on the **backend host** (for local development, in `mindguard-backend/.env`, which must not be committed):

```text
LLM_PROVIDER=groq
GROQ_API_KEY=your-Groq-key
GROQ_MODEL=openai/gpt-oss-120b
```

`GROQ_MODEL` is optional in this code; the default is `openai/gpt-oss-120b`. If the hosting dashboard has an old `GROQ_MODEL=llama-3.3-70b-versatile` override, replace or remove it. Groq shut down `llama-3.3-70b-versatile` for free/developer accounts on 2026-08-16. See [Groq model deprecations](https://console.groq.com/docs/deprecations) and [supported models](https://console.groq.com/docs/models).

Never put `GROQ_API_KEY` in a `VITE_*` variable or frontend `.env` file; frontend values are public after build. For OpenRouter, set `LLM_PROVIDER=openrouter`, `OPENROUTER_API_KEY`, and optionally `OPENROUTER_MODEL` instead.

## Verification

From `mindguard-backend`:

```text
python -m unittest discover -s tests -p test_ai_interview.py -v
```

The interview now continues until every required field in `engine/schema.py` has a validated value. It no longer force-completes after six turns or inserts neutral/default values. One user reply may fill multiple fields; incomplete answers leave the remaining fields for follow-up questions.
