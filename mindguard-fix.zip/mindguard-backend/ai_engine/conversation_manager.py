from .structured_extractor import parse_model_response
from .llm_connector import ask_llm, LLMServiceError
from .prompt_builder import build_prompt
from .state_manager import create_state, update_state, is_complete



def _legacy_process_message(message, state=None):
    raise NotImplementedError("Use process_message; legacy keyword extraction is disabled.")




    if state is None:

        state = create_state()



    # Store student message

    state["history"].append(

        {
            "role": "student",
            "content": message
        }

    )



    # -----------------------------
    # Ask LLM to conduct interview
    # -----------------------------

    prompt = build_prompt(

        state["history"],

        state,

        message

    )


    reply = ask_llm(prompt, state)



    # Store AI response

    state["history"].append(

        {
            "role": "assistant",
            "content": reply
        }

    )



    # -----------------------------
    # Extract facts from conversation
    # -----------------------------

    combined_text = "\n".join(

        item["content"]

        for item in state["history"]

    )



    facts = extract_facts(

        combined_text

    )



    state = update_state(

        state,

        facts

    )



    # -----------------------------
    # Completion check
    # -----------------------------

    if is_complete(state):


        return {


            "complete": True,


            "data": state["data"],


            "state": state


        }



    return {


        "complete": False,


        "reply": reply,


        "state": state


    }


def process_message(message, state=None):
    if not isinstance(message, str) or not message.strip():
        raise ValueError("message must be a non-empty string")
    if state is None:
        state = create_state()
    state.setdefault("history", []).append({"role": "user", "content": message})

    prompt = build_prompt(state["history"], state, message)
    raw_response = ask_llm(prompt)
    try:
        parsed = parse_model_response(raw_response, message)
    except ValueError as error:
        raise LLMServiceError("AI returned data that could not be safely validated.") from error

    state = update_state(state, parsed["facts"])
    state["history"].append({"role": "assistant", "content": parsed["reply"]})

    if is_complete(state):
        return {"complete": True, "reply": parsed["reply"], "data": state["data"], "state": state}
    return {"complete": False, "reply": parsed["reply"], "state": state}
