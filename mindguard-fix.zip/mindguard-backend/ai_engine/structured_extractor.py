import json
import math

from engine.normalizer import ORDINAL_MAP
from engine.schema import ENGINE_SCHEMA


class ExtractionError(ValueError):
    """The model response could not be safely parsed."""


def _valid_fact(fact, user_message):
    if not isinstance(fact, dict):
        return None
    category = fact.get("category")
    field = fact.get("field")
    evidence = fact.get("evidence")
    value = fact.get("value")
    if not isinstance(category, str) or not isinstance(field, str):
        return None
    if not isinstance(evidence, str) or not evidence.strip():
        return None
    if evidence.casefold() not in user_message.casefold():
        return None

    rules = ENGINE_SCHEMA.get(category, {}).get(field)
    if not rules or not rules.get("required", False):
        return None

    field_type = rules.get("type")
    if field_type in ("continuous", "percentage"):
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            return None
        if not math.isfinite(value):
            return None
        if "min" in rules and value < rules["min"]:
            return None
        if "max" in rules and value > rules["max"]:
            return None
        return category, field, value

    if field_type == "ordinal" and isinstance(value, str):
        canonical = next((label for label in ORDINAL_MAP if label.casefold() == value.casefold()), None)
        if canonical is not None:
            return category, field, canonical
    return None


def parse_model_response(output: str, user_message: str):
    try:
        payload = json.loads(output)
    except (json.JSONDecodeError, TypeError) as error:
        raise ExtractionError("AI response was not valid JSON.") from error

    if not isinstance(payload, dict):
        raise ExtractionError("AI response must be a JSON object.")
    reply = payload.get("reply")
    candidates = payload.get("facts", [])
    if not isinstance(reply, str) or not reply.strip():
        raise ExtractionError("AI response did not include a reply.")
    if not isinstance(candidates, list):
        raise ExtractionError("AI response facts must be a list.")

    facts = {}
    for candidate in candidates:
        validated = _valid_fact(candidate, user_message)
        if validated is None:
            continue
        category, field, value = validated
        facts.setdefault(category, {})[field] = value
    return {"reply": reply.strip(), "facts": facts}


def extract_facts(output: str, user_message: str):
    """Return only schema-valid facts grounded in the latest user message."""
    return parse_model_response(output, user_message)["facts"]
